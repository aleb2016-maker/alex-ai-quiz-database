package com.alex.quizengine

import kotlin.random.Random

data class FinalReward(
    val title: String,
    val message: String,
    val drawing: String,
    val score: Int,
    val total: Int
)

data class ConfettiSpec(
    val pieces: Int = 46,
    val startsFromBottom: Boolean = true,
    val wideSpread: Boolean = true,
    val softMotion: Boolean = true
)

object FinalRewardEngine {
    private val perfect = listOf(
        Triple("Missione perfetta", "Hai chiuso il test con precisione totale. Questa è mentalità da progetto professionale.", "🚀"),
        Triple("Prestazione eccellente", "Risposte pulite, ritmo alto e zero errori: ottimo segnale per un percorso AI ITS.", "🧠"),
        Triple("Dominio completo", "Hai gestito il test come un sistema ben addestrato: dati chiari, decisioni corrette, risultato massimo.", "🏆")
    )

    private val excellent = listOf(
        Triple("Quasi perfetto", "Ti manca pochissimo al massimo. La base è fortissima, ora serve solo rifinire i dettagli.", "⚡"),
        Triple("Livello molto alto", "Hai dimostrato controllo e ragionamento. Un errore non rovina una prova così solida.", "🤖"),
        Triple("Prestazione distinta", "Sei già in una zona alta: continua così e il 10 diventa naturale.", "🌟")
    )

    private val good = listOf(
        Triple("Ottimo risultato", "Hai superato bene il test. Ora lavora sui dettagli che separano il buono dall'eccellente.", "🔥"),
        Triple("Ragionamento solido", "Il risultato mostra comprensione reale. Con un po' di revisione puoi salire ancora.", "💡"),
        Triple("Buona padronanza", "Le basi ci sono e si vedono. Ora punta a rendere più stabili anche le risposte difficili.", "🧩")
    )

    private val medium = listOf(
        Triple("Buona prova", "Stai costruendo una base concreta. Rivedi gli errori e trasformali in punti forti.", "📈"),
        Triple("In crescita", "Il risultato è positivo. Ora serve consolidare gli argomenti dove hai esitato.", "🔧"),
        Triple("Base valida", "Hai materiale su cui costruire. La prossima prova può salire molto.", "🛠️")
    )

    private val minimum = listOf(
        Triple("Sufficiente", "Hai superato la soglia. Ora bisogna rendere più sicure le risposte e ridurre gli errori evitabili.", "🧱"),
        Triple("Strada giusta", "La direzione è buona, ma serve più allenamento sui concetti chiave.", "🧭"),
        Triple("Da consolidare", "Il test è passato, ma il prossimo obiettivo è trasformare il minimo in sicurezza.", "📚")
    )

    private val low = listOf(
        Triple("Riprova strategica", "Non è una bocciatura: è una mappa degli argomenti da rinforzare.", "🔁"),
        Triple("Test diagnostico", "Questo risultato ti dice dove intervenire. Riparti dagli errori e migliora a blocchi.", "🧪"),
        Triple("Allenamento utile", "Ogni errore è un dato. Usalo per capire cosa rivedere prima del prossimo tentativo.", "🧠")
    )

    fun rewardFor(score: Int, total: Int): FinalReward {
        val safeTotal = total.coerceAtLeast(1)
        val voto = ((score.toDouble() / safeTotal.toDouble()) * 10.0).toInt()

        val bucket = when {
            voto >= 10 -> perfect
            voto >= 9 -> excellent
            voto >= 8 -> good
            voto >= 7 -> medium
            voto >= 6 -> minimum
            else -> low
        }

        val selected = bucket[Random.nextInt(bucket.size)]

        return FinalReward(
            title = selected.first,
            message = selected.second,
            drawing = selected.third,
            score = score,
            total = total
        )
    }

    fun confettiForCorrectAnswer(): ConfettiSpec {
        return ConfettiSpec(
            pieces = 46,
            startsFromBottom = true,
            wideSpread = true,
            softMotion = true
        )
    }
}
