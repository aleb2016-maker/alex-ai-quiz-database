# Pacchetto RAG riutilizzabile

Questo ZIP contiene il motore RAG scaricabile e riutilizzabile.

Comando esempio:

    python3 scripts/rag_documenti_aziendali.py rag/documenti/esempio_documento_aziendale_formazione.md --titolo "Formazione aziendale" --output all

Per PDF/DOCX possono servire:

    pip install pypdf python-docx
