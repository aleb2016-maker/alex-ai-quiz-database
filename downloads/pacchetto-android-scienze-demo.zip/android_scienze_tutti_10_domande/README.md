# Pacchetto quiz generato

Piattaforma: android
Materia: scienze
Livello: tutti
Domande: 10

## Web

Apri:

1_APRI_QUIZ.html

## Android

Copia:

app/src/main/assets/database_quiz.json
