#!/bin/bash
clear
echo "IMPORTA PACCHETTO QUIZ IN ANDROID STUDIO"
echo ""
echo "Questo comando copierà automaticamente:"
echo "- database_quiz.json"
echo "- file Kotlin del motore quiz"
echo ""
echo "Trascina qui la cartella principale del tuo progetto Android Studio e premi INVIO:"
read PROJECT_DIR

PROJECT_DIR="${PROJECT_DIR//\ / }"
PROJECT_DIR="${PROJECT_DIR%/}"

if [ ! -d "$PROJECT_DIR/app/src/main" ]; then
  echo ""
  echo "ERRORE: questa non sembra una cartella valida di progetto Android."
  echo "Deve contenere: app/src/main"
  echo ""
  read -p "Premi INVIO per chiudere."
  exit 1
fi

DIR="$(cd "$(dirname "$0")" && pwd)"

mkdir -p "$PROJECT_DIR/app/src/main/assets"
cp "$DIR/app/src/main/assets/database_quiz.json" "$PROJECT_DIR/app/src/main/assets/database_quiz.json"

mkdir -p "$PROJECT_DIR/app/src/main/java/com/alex/quizengine"
cp "$DIR/quiz_engine_android/kotlin/com/alex/quizengine/"*.kt "$PROJECT_DIR/app/src/main/java/com/alex/quizengine/"

echo ""
echo "IMPORTAZIONE COMPLETATA."
echo ""
echo "File copiati:"
echo "1. $PROJECT_DIR/app/src/main/assets/database_quiz.json"
echo "2. $PROJECT_DIR/app/src/main/java/com/alex/quizengine/"
echo ""
echo "Ora apri il progetto in Android Studio e collega la tua interfaccia grafica al motore."
echo ""
read -p "Vuoi aprire ora il progetto in Android Studio? scrivi s e premi INVIO: " RISPOSTA

if [ "$RISPOSTA" = "s" ] || [ "$RISPOSTA" = "S" ]; then
  open -a "Android Studio" "$PROJECT_DIR"
fi
