#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
open "$DIR/APRI LE ISTRUZIONI.html"
