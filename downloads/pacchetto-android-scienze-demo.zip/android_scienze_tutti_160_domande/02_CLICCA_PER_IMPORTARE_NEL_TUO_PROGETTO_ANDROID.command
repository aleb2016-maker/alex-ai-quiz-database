#!/bin/bash
clear
echo "02 - IMPORTA TUTTO NEL TUO PROGETTO ANDROID"
echo ""
echo "Trascina qui la cartella principale del tuo progetto Android Studio e premi INVIO:"
read PROJECT_DIR

PROJECT_DIR="${PROJECT_DIR//\ / }"
PROJECT_DIR="${PROJECT_DIR%/}"

if [ ! -d "$PROJECT_DIR/app/src/main" ]; then
  echo ""
  echo "ERRORE: questa non sembra una cartella valida di progetto Android."
  echo "La cartella deve contenere: app/src/main"
  echo ""
  read -p "Premi INVIO per chiudere."
  exit 1
fi

DIR="$(cd "$(dirname "$0")" && pwd)"
SOURCE="$DIR/03_NON_APRIRE_FILE_TECNICI_USATI_DAL_PULSANTE"

mkdir -p "$PROJECT_DIR/app/src/main/assets"
cp "$SOURCE/app/src/main/assets/database_quiz.json" "$PROJECT_DIR/app/src/main/assets/database_quiz.json"

mkdir -p "$PROJECT_DIR/app/src/main/java/com/alex/quizengine"
cp "$SOURCE/app/src/main/java/com/alex/quizengine/"*.kt "$PROJECT_DIR/app/src/main/java/com/alex/quizengine/"

echo ""
echo "IMPORTAZIONE COMPLETATA."
echo ""
echo "Database copiato in:"
echo "$PROJECT_DIR/app/src/main/assets/database_quiz.json"
echo ""
echo "Motore Kotlin copiato in:"
echo "$PROJECT_DIR/app/src/main/java/com/alex/quizengine/"
echo ""
read -p "Vuoi aprire ora il progetto in Android Studio? scrivi s e premi INVIO: " RISPOSTA

if [ "$RISPOSTA" = "s" ] || [ "$RISPOSTA" = "S" ]; then
  open -a "Android Studio" "$PROJECT_DIR"
fi
